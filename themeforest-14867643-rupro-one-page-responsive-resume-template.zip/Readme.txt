Thank you for your recent purchase of ((RuPRO - One Page Responsive Resume Template)).

--------------------------------------


Overview:

RuPRO is a modern and exclusive HTML5 theme for resume, personal and portfolio.
Theme focused on digital professionals, whether designers, programmers or photographers. It is perfect to promote your work!


--------------------------------------


Features:

- semantic html 5
- use BEM
- valid HTML & CSS
- unique Design
- 4 HTML5 Pages
- 10 preloaders
- 17 effects for mobile menu
- available in 11 colors
- 5 fonts for theme
- SVG icons
- full responsive
- easy customization
- youtube Video Background
- skill Progress bar
- many effects for animation blocks
- unique and interactive modal window
- less and sass files
- detailed documentation


--------------------------------------


Icons used (SVG Icons) :

- Icomoon - https://icomoon.io/


--------------------------------------


Free Google Fonts used :

- Google Fonts, RALEWAY
- Google Fonts, SOURCE SANS PRO
- Google Fonts, BITTER DOSIS
- Google Fonts, MERRIWEATHER SANS
- Google Fonts, ROBOTO 


--------------------------------------


Photos Credits:

� https://stocksnap.io/
� https://www.pexels.com/
� https://pixabay.com/


IMPORTANT: Images used in the Preview demo are not included in the downloaded package.


If you have any questions or need customization, please contact me via e-mail or through my profile page. I'm here to help!

ThemeForest: http://themeforest.net/user/melnik9099
Email: melnik909@ya.ru


Good luck.